﻿// --------------------------------------------------------------------------------------------------------------------
//File Name: Program.cs

//Description: This class submit the number and get the word equals to the submitted number.

//Author: Venu Moguram

//Created on: 28-August-2019

//Modified By:

//Modified on

// --------------------------------------------------------------------------------------------------------------------

namespace NumberToWordConverterApplication
{
    #region Using

    using System;

    #endregion

    /// <summary>
    /// This class submit the number and get the word equals to the submitted number.
    /// </summary>
    class Program
    {
        #region Main Method

        /// <summary>
        /// Main method to start the console.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter a Number which need to be show in words.");
                string inputNumber = Console.ReadLine();

                // Start the process
                Console.WriteLine(NumberToWordConverter.StartConverting(inputNumber));

                // Close application.
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        #endregion
    }
}
