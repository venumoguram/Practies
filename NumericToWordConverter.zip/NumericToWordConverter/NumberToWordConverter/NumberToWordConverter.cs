﻿// --------------------------------------------------------------------------------------------------------------------
//File Name: NumberToWordConverter.cs

//Description: This class contains the logic to convert the given inputNumber into its equivalant word.

//Author: Venu Moguram

//Created on: 28-August-2019

//Modified By:

//Modified on

// --------------------------------------------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberToWordConverterApplication
{
    /// <summary>
    /// This class contains the logic to convert the given inputNumber into its equivalant word.
    /// </summary>
    internal class NumberToWordConverter
    {
        #region Public Method(s)

        /// <summary>
        /// Starts the process of converting given number
        /// </summary>
        /// <param name="number">Number to be converted in words</param>
        public static string StartConverting(string number)
        {
            if (string.IsNullOrWhiteSpace(number))
                return "Null or empty value is not accepted. Please enter a valid number.";

            if (!char.IsDigit(number, 0) && number.Length == 1)
                return "Please enter a valid number.";

            if (!char.IsDigit(number, 0) && number.Length > 1 && number.Substring(0, 1) != "-")
                return "Please enter a valid number.";

            string isNegative = "";

            number = Convert.ToDouble(number).ToString();

            // Check for negative numbers.
            if (number.Contains("-"))
            {
                isNegative = "Minus ";
                number = number.Substring(1, number.Length - 1);
            }
            if (number == "0")
            {
                return "The number in words is \nZero Only";
            }
            else
            {
                return string.Format("The number in words is \n{0}", isNegative + ConvertToWords(number));
            }
        }

        #endregion

        #region Private Method(s)

        /// <summary>
        /// Convert the given numner to word.
        /// </summary>
        /// <param name="number">The number which need to be converted.</param>
        /// <returns>Returns the word equivavalent to the given numbner.</returns>
        private static string ConvertToWords(string number)
        {
            string val = "", wholeNo = number, points = "", andString = "", pointString = "";
            string endString = "Only";
            try
            {
                int decimalPlace = number.IndexOf(".");
                if (decimalPlace > 0)
                {
                    wholeNo = number.Substring(0, decimalPlace);
                    points = number.Substring(decimalPlace + 1);
                    if (Convert.ToInt32(points) > 0)
                    {
                        andString = "and";
                        endString = "Paisa " + endString;
                        pointString = ConvertDecimals(points);
                    }
                }
                val = String.Format("{0} {1}{2} {3}", ConvertWholeNumber(wholeNo).Trim(), andString, pointString, endString);
            }
            catch { }
            return val;
        }

        /// <summary>
        /// Convert to word equivalant whole number hundreds, thousands, millions and billions
        /// </summary>
        /// <param name="Number">The Number to be converted</param>
        /// <returns>Retuns the word equivalant</returns>
        private static string ConvertWholeNumber(string Number)
        {
            string word = "";
            try
            {
                bool beginsZero = false;
                bool isDone = false;
                double dblAmt = (Convert.ToDouble(Number));
                if (dblAmt > 0)
                {
                    beginsZero = Number.StartsWith("0");

                    int numDigits = Number.Length;
                    int pos = 0;
                    string place = "";
                    switch (numDigits)
                    {
                        case 1://ones

                            word = ones(Number);
                            isDone = true;
                            break;
                        case 2://tens
                            word = tens(Number);
                            isDone = true;
                            break;
                        case 3://hundreds
                            pos = (numDigits % 3) + 1;
                            place = " Hundred ";
                            break;
                        case 4://thousands
                        case 5:
                        case 6:
                            pos = (numDigits % 4) + 1;
                            place = " Thousand ";
                            break;
                        case 7://millions
                        case 8:
                        case 9:
                            pos = (numDigits % 7) + 1;
                            place = " Million ";
                            break;
                        case 10://Billions
                        case 11:
                        case 12:

                            pos = (numDigits % 10) + 1;
                            place = " Billion ";
                            break;
                        default:
                            isDone = true;
                            break;
                    }
                    if (!isDone)
                    {
                        if (Number.Substring(0, pos) != "0" && Number.Substring(pos) != "0")
                        {
                            try
                            {
                                word = ConvertWholeNumber(Number.Substring(0, pos)) + place + ConvertWholeNumber(Number.Substring(pos));
                            }
                            catch { }
                        }
                        else
                        {
                            word = ConvertWholeNumber(Number.Substring(0, pos)) + ConvertWholeNumber(Number.Substring(pos));
                        }

                    }
                    if (word.Trim().Equals(place.Trim())) word = "";
                }
            }
            catch { }
            return word.Trim();
        }

        /// <summary>
        /// All tens position numbers
        /// </summary>
        /// <param name="Number">Number which is in tens position</param>
        /// <returns>Retuns the word equivalant</returns>
        private static string tens(string Number)
        {
            int _Number = Convert.ToInt32(Number);
            string name = null;
            switch (_Number)
            {
                case 10:
                    name = "Ten";
                    break;
                case 11:
                    name = "Eleven";
                    break;
                case 12:
                    name = "Twelve";
                    break;
                case 13:
                    name = "Thirteen";
                    break;
                case 14:
                    name = "Fourteen";
                    break;
                case 15:
                    name = "Fifteen";
                    break;
                case 16:
                    name = "Sixteen";
                    break;
                case 17:
                    name = "Seventeen";
                    break;
                case 18:
                    name = "Eighteen";
                    break;
                case 19:
                    name = "Nineteen";
                    break;
                case 20:
                    name = "Twenty";
                    break;
                case 30:
                    name = "Thirty";
                    break;
                case 40:
                    name = "Fourty";
                    break;
                case 50:
                    name = "Fifty";
                    break;
                case 60:
                    name = "Sixty";
                    break;
                case 70:
                    name = "Seventy";
                    break;
                case 80:
                    name = "Eighty";
                    break;
                case 90:
                    name = "Ninety";
                    break;
                default:
                    if (_Number > 0)
                    {
                        name = tens(Number.Substring(0, 1) + "0") + " " + ones(Number.Substring(1));
                    }
                    break;
            }
            return name;
        }

        /// <summary>
        /// All ones position numbers
        /// </summary>
        /// <param name="Number">Number which is in ones position</param>
        /// <returns>Retuns the word equivalant</returns>
        private static string ones(string Number)
        {
            int _Number = Convert.ToInt32(Number);
            string name = "";
            switch (_Number)
            {

                case 1:
                    name = "One";
                    break;
                case 2:
                    name = "Two";
                    break;
                case 3:
                    name = "Three";
                    break;
                case 4:
                    name = "Four";
                    break;
                case 5:
                    name = "Five";
                    break;
                case 6:
                    name = "Six";
                    break;
                case 7:
                    name = "Seven";
                    break;
                case 8:
                    name = "Eight";
                    break;
                case 9:
                    name = "Nine";
                    break;
            }
            return name;
        }

        /// <summary>
        /// Converts points to decimal
        /// </summary>
        /// <param name="number">Number to be converted to decimal</param>
        /// <returns>Returns converted decimal points</returns>
        private static string ConvertDecimals(string number)
        {
            string cd = "", digit = "", engOne = "";
            for (int i = 0; i < number.Length; i++)
            {
                digit = number[i].ToString();
                if (digit.Equals("0"))
                {
                    engOne = "Zero";
                }
                else
                {
                    engOne = ones(digit);
                }
                cd += " " + engOne;
            }
            return cd;
        }

        #endregion
    }
}
