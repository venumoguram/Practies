﻿// --------------------------------------------------------------------------------------------------------------------
//File Name: NumberToWordConverterTest.cs

//Description: This class holds all the test methods for NumberToWordConverterApplication.

//Author: Venu Moguram

//Created on: 28-August-2019

//Modified By:

//Modified on

// --------------------------------------------------------------------------------------------------------------------

namespace NumberToWordConverterApplication
{
    #region Using

    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    #endregion

    /// <summary>
    /// This class holds all the test methods for NumberToWordConverterApplication.
    /// </summary>
    [TestClass]
    public class NumberToWordConverterTest
    {
        [TestMethod]
        public void StartConvertingNullTest()
        {
            string inputNumber = null;
            string actualOutPut = NumberToWordConverter.StartConverting(inputNumber);
            string expected = "Null or empty value is not accepted. Please enter a valid number.";
            Assert.AreEqual(expected, actualOutPut);
        }

        [TestMethod]
        public void StartConvertingEmptyTest()
        {
            string inputNumber = string.Empty;
            string actualOutPut = NumberToWordConverter.StartConverting(inputNumber);
            string expected = "Null or empty value is not accepted. Please enter a valid number.";
            Assert.AreEqual(expected, actualOutPut);
        }

        [TestMethod]
        public void StartConvertingSpaceTest()
        {
            string inputNumber = " ";
            string actualOutPut = NumberToWordConverter.StartConverting(inputNumber);
            string expected = "Null or empty value is not accepted. Please enter a valid number.";
            Assert.AreEqual(expected, actualOutPut);
        }

        [TestMethod]
        public void StartConvertingSpecialCharacterTest()
        {
            string inputNumber = "*";
            string actualOutPut = NumberToWordConverter.StartConverting(inputNumber);
            string expected = "Please enter a valid number.";
            Assert.AreEqual(expected, actualOutPut);
        }

        [TestMethod]
        public void StartConvertingInvalidSpecialCharacterAndNumberTest()
        {
            string inputNumber = "*1";
            string actualOutPut = NumberToWordConverter.StartConverting(inputNumber);
            string expected = "Please enter a valid number.";
            Assert.AreEqual(expected, actualOutPut);
        }

        [TestMethod]
        public void StartConvertingvalidSpecialCharacterAndNumberTest()
        {
            string inputNumber = "-1";
            string actualOutPut = NumberToWordConverter.StartConverting(inputNumber);
            string expected = "The number in words is \nMinus One  Only";
            Assert.AreEqual(expected, actualOutPut);
        }

        [TestMethod]
        public void StartConvertingZeroTest()
        {
            string inputNumber = "0";
            string actualOutPut = NumberToWordConverter.StartConverting(inputNumber);
            string expected = "The number in words is \nZero Only";
            Assert.AreEqual(expected, actualOutPut);
        }

        [TestMethod]
        public void StartConvertingValidNumberTest()
        {
            string inputNumber = "2525";
            string actualOutPut = NumberToWordConverter.StartConverting(inputNumber);
            string expected = "The number in words is \nTwo Thousand Five Hundred Twenty Five  Only";
            Assert.AreEqual(expected, actualOutPut);
        }
    }
}
